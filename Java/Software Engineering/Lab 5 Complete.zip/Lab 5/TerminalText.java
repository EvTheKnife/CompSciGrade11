
/*
 * 12/03/24
 * Chell, David H
 * Just an unnecessary class
 */
public class TerminalText {

  public static void printHello() {
    System.out.println("Hello");
  }
  

}
